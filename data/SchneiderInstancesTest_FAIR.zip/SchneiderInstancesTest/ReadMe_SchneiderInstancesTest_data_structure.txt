README – Schneider EVRP instance file structure

This archive contains benchmark instances for the Electric Vehicle Routing Problem (EVRP)
used in the manuscript:

"Evolving ensembles of routing policies for the electric vehicle routing problem using hyper-heuristic methods"
Submitted to Applied Soft Computing Journal
Manuscript reference: ASOC-D-25-12027

File organisation
-----------------
- Original instance files are provided as plain-text `.txt` files.
- Open-format CSV versions of the same data are provided under:
  - `open_formats/csv/nodes/`
  - `open_formats/csv/parameters/`

Each original `.txt` instance is represented by two CSV files:

1. Node table
   Path: `open_formats/csv/nodes/<instance_name>__nodes.csv`

   Columns:
   - `StringID`: Node identifier. Prefix `D` denotes depot, `S` denotes charging station, and `C` denotes customer.
   - `Type`: Node type. `d` = depot, `f` = charging station, `c` = customer.
   - `x`: X coordinate of the node.
   - `y`: Y coordinate of the node.
   - `demand`: Customer demand. Depots and charging stations have zero demand.
   - `ReadyTime`: Earliest service start time.
   - `DueDate`: Latest service start time.
   - `ServiceTime`: Service duration at the node.

2. Parameter table
   Path: `open_formats/csv/parameters/<instance_name>__parameters.csv`

   Columns:
   - `parameter`: Parameter identifier.
   - `description`: Description of the parameter.
   - `value`: Parameter value.

   Parameters:
   - `Q`: Vehicle fuel/battery capacity.
   - `C`: Vehicle load capacity.
   - `r`: Fuel or energy consumption rate.
   - `g`: Inverse refuelling/recharging rate.
   - `v`: Average vehicle velocity.

Training/test split
-------------------
Training instances are intended for the learning or policy-evolution phase.
Test instances are intended for independent final evaluation.

Reproducibility notes
---------------------
- Original filenames should be preserved because they encode the instance family and size.
- CSV files are derived directly from the original `.txt` files without modifying the data values.
- SHA-256 checksums are included in `CHECKSUMS.txt` to support integrity verification.

License
-------
Unless otherwise stated in the repository, these data files and derived CSV files are distributed
under the Creative Commons Attribution 4.0 International License (CC BY 4.0).
